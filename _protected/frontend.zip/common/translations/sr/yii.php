<?php

return [
    '{attribute} cannot be blank.' => 'polje {attribute} ne sme biti prazno.',
    'The verification code is incorrect.' => 'Antispam kod nije tačan.',
    'Home' => 'Početna',
    'You are not allowed to perform this action.' => 'Nije Vam dozvoljeno da to uradite.'
];