<?php

return [
    '{attribute} cannot be blank.' => '{attribute} não pode estar em branco.',
    'The verification code is incorrect.' => 'Código de verificação incorreto.',
    'Home' => 'Início',
    'You are not allowed to perform this action.' => 'Você não está autorizado a realizar esta ação.'
];
