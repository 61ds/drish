<?php

/* @var $this yii\web\View */
$this->title = 'Drish Dashboard';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Welcome!</h1>


    </div>

    <div class="body-content">

        <div class="row">

        </div>

    </div>
</div>

