<div class="detail-shipping">
    <div class="shipping-main">
        <div class="shipping-method">
            <div class="free-s">Cash on delivery</div>
        </div>
        <!-- end of contact information fiels-->
        <hr class="border-line">
        <div class="btn-cart red-btn">   <!--button type="button" class="blk-btn">BACK</button--> <button type="button">CONTINUE</button> </div>
    </div>
</div>